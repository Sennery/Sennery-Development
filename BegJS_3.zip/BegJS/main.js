document.body.classList.remove("hidecontent");

setTimeout(function(){
	document.getElementById('sign').classList.remove("hidecontent");
},1000);

setTimeout(function(){
	document.getElementById('skobkiLeft').classList.add('blink');
	document.getElementById('skobkiRight').classList.add('blink');
},4000);

setInterval(function(){

	document.getElementById('s').classList.add('hide');
	document.getElementById('e').classList.add('hide');
	document.getElementById('n').classList.add('hide');
	document.getElementById('y').classList.add('hide');
	document.getElementById('a').classList.add('hide');

	setTimeout(function(){
		document.getElementById('s').classList.remove('hide');
		document.getElementById('e').classList.remove('hide');
		document.getElementById('n').classList.remove('hide');
		document.getElementById('y').classList.remove('hide');
		document.getElementById('a').classList.remove('hide');
	},2000);
},5000);

skobkiLeft.onmouseover=skobkiRight.onmouseover= handlerOver;
skobkiLeft.onmouseout=skobkiRight.onmouseout= handlerOut;


function handlerOver(event){
	document.getElementById('skobkiLeft').classList.remove('blink');
	document.getElementById('skobkiRight').classList.remove('blink');
}
function handlerOut(event){
	document.getElementById('skobkiLeft').classList.add('blink');
	document.getElementById('skobkiRight').classList.add('blink');
}

var main = document.getElementById('main');
var icons = document.getElementById('icons');

window.onscroll = function(){
	var scrolled = window.pageYOffset;
	main.style.backgroundPositionY = scrolled/5 + "px";

	icons.style.opacity = 1 - scrolled/50;

	if(icons.style.opacity <= 0)icons.style.display="none";
	else icons.style.display="inline-block";
}